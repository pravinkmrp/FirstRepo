package com.example;

import guru.nidi.graphviz.attribute.Color;
import guru.nidi.graphviz.attribute.Font;
import guru.nidi.graphviz.attribute.Rank;
import guru.nidi.graphviz.engine.Format;
import guru.nidi.graphviz.engine.Graphviz;
import guru.nidi.graphviz.model.Graph;
import guru.nidi.graphviz.model.LinkSource;

import static guru.nidi.graphviz.model.Factory.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static guru.nidi.graphviz.attribute.Attributes.attr;
import static guru.nidi.graphviz.attribute.Rank.RankDir.LEFT_TO_RIGHT;

public class App 
{
    public static Map<String, String> csv_as_map(String filePath) {
        HashMap<String, String> map = new HashMap<>();
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            line = reader.readLine();
            while ((line = reader.readLine()) != null) {
                String[] keyValuePair = line.split(",");
                if (keyValuePair.length > 1) {
                    String key = keyValuePair[0].toString();
                    String value = keyValuePair[1].toString();
                    System.out.println(key+value);
                    map.put(key, value);
                } 
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return map;
    }

    public static List<List<String>> csv_as_array(String filePath) {
        List<List<String>> records = new ArrayList<>();
        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            line = reader.readLine();
            while ((line = reader.readLine()) != null) {
                String[] values = line.split(",");
                
                if ( values.length == 2 ) {
                    records.add(Arrays.asList(values));
                    System.out.println(values[0]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return records;
    }

    public static void upsert_map(Map<String, ArrayList<String>> map_collection, String key, String value) {
        if (map_collection.get(key) == null ) {
            ArrayList<String> d = new ArrayList<String>();
            d.add(value);
            map_collection.put(key,d);
        } else {
            ArrayList<String> d = map_collection.get(key);
            d.add(value);
            map_collection.put(key,d);
        }
    }

    public static void main( String[] args ) throws FileNotFoundException
    {
        System.out.println( "Generating Dependency Graph!" );
        
        Map<String, String> package_map = csv_as_map("C:\\Users\\1000034527\\work\\projects\\graph-poc\\packagemap.csv");
        List<List<String>> class_links = csv_as_array("C:\\Users\\1000034527\\work\\projects\\graph-poc\\classlinks.csv");
        Set<String> pkg_dataset = new HashSet<String> (); 
        Set<String> cls_dataset = new HashSet<String> (); 

        Map<String, ArrayList<String>> package_collection = new HashMap<>();

        for (List<String> entry : class_links) {
            String node1 = entry.get(0);
            String node2 = entry.get(1);
            
            String package1 = package_map.getOrDefault(node1, "NoPackage");
            String package2 = package_map.getOrDefault(node2, "NoPackage");

            pkg_dataset.add(package1+","+package2);
            cls_dataset.add(node1+","+node2);

            // Save package collection
            upsert_map(package_collection,package1,node1);
            upsert_map(package_collection,package2,node2);
        }
        
        // Generate package level graph
        List<LinkSource> graph_entries = new ArrayList<>();
        for (String entry : pkg_dataset) {
            String[] values = entry.split(",");
            graph_entries.add(node(values[0]).link(node(values[1])));
            if (values[0].contains("*")) {
                graph_entries.add(node(values[0]).with(Color.RED));
            } 
            if (values[1].contains("*")) {
                graph_entries.add(node(values[1]).with(Color.RED));
            } 
            graph_entries.add(node(values[0]).link(node(values[1])));
        }
        
        Graph g = graph("example1").directed()
                    .graphAttr().with(Rank.dir(LEFT_TO_RIGHT))
                    .linkAttr().with("class", "link-class")
                    .graphAttr().with(attr("pad","0.5"),attr("ranksep","0.5"),attr("nodesep","0.5"))
                    .nodeAttr().with(Font.name("Arial"))
                    .with(graph_entries);
                    
        try {
            Graphviz.fromGraph(g).width(5000).render(Format.PNG).toFile(new File("pkg_graph.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        // // Generate class level graph
        graph_entries.clear();

        // // Generate package clusters
        // for (Map.Entry<String, ArrayList<String>> entry : package_collection.entrySet()) {
        //     String key = entry.getKey();
        //     List<String> values = entry.getValue();

        //     List<LinkSource> node_list = new ArrayList<>();
        //     for( String k : values) {
        //         node_list.add(node(k));
        //     }
        //     graph_entries.add(graph(key).cluster()
        //             .nodeAttr().with(Style.FILLED, Color.WHITE)
        //             .graphAttr().with(Style.FILLED, Color.LIGHTGREY, Label.of(key))
        //             .with(node_list));
        // }

        for (String entry : cls_dataset) {
            String[] values = entry.split(",");
            graph_entries.add(node(values[0]).link(node(values[1])));
            if (values[0].contains("*")) {
                graph_entries.add(node(values[0]).with(Color.RED));
            } 
            if (values[1].contains("*")) {
                graph_entries.add(node(values[1]).with(Color.RED));
            } 
            graph_entries.add(node(values[0]).link(node(values[1])));
        }

        Graph g2 = graph("example1").directed()
                    .graphAttr().with(Rank.dir(LEFT_TO_RIGHT))
                    .linkAttr().with("class", "link-class")
                    .graphAttr().with(attr("pad","0.5"),attr("ranksep","2"),attr("nodesep","0.5"))
                    .nodeAttr().with(Font.name("Arial"))
                    .with(graph_entries);
        try {
            Graphviz.fromGraph(g2).height(10000).render(Format.PNG).toFile(new File("cls_graph.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
