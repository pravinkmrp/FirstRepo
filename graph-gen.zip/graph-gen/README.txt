

Run extracter.ps1 - command
'''powershell -ExecutionPolicy Bypass -File .\extracter.ps1'''

Create pom_dependency.csv in current folder where the jar exists
Ensure all these 3 files exists in current folder - pom_dependency.csv, class_dependency.csv, package_map.csv

Run jar command
'''java -jar .\target\demo-1.0-SNAPSHOT-jar-with-dependencies.jar'''
