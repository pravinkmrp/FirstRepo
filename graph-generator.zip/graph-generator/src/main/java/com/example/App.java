package com.example;

import static guru.nidi.graphviz.attribute.Attributes.attr;
import static guru.nidi.graphviz.attribute.Rank.RankDir.LEFT_TO_RIGHT;
import static guru.nidi.graphviz.model.Factory.graph;
import static guru.nidi.graphviz.model.Factory.node;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.github.javaparser.ParseResult;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.utils.SourceRoot;
import com.google.common.base.Optional;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

import org.apache.commons.io.FileUtils;

import guru.nidi.graphviz.attribute.Color;
import guru.nidi.graphviz.attribute.Font;
import guru.nidi.graphviz.attribute.Label;
import guru.nidi.graphviz.attribute.Rank;
import guru.nidi.graphviz.attribute.Style;
import guru.nidi.graphviz.engine.Format;
import guru.nidi.graphviz.engine.Graphviz;
import guru.nidi.graphviz.model.Graph;
import guru.nidi.graphviz.model.LinkSource;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.ParseException;


public class App {
    static Path test_folder_path = Paths.get("src", "test");

    public static Map<String, String> csv_as_map(String filePath) {
        HashMap<String, String> map = new HashMap<>();
        String[] record;
        try (CSVReader reader = new CSVReader(new FileReader(filePath))) {
            reader.readNext(); // Skip Header
            while ((record = reader.readNext()) != null) {
                if (record.length > 1) {
                    String key = record[0].toString();
                    String value = record[1].toString();
                    map.put(key, value);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return map;
    }

    public static List<String[]> csv_as_array(String filePath) {
        try (CSVReader reader = new CSVReader(new FileReader(filePath))) {
            reader.readNext(); // Skip Header
            return reader.readAll();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void upsert_map(Map<String, ArrayList<String>> map_collection, String key, String value) {
        if (map_collection.get(key) == null) {
            ArrayList<String> d = new ArrayList<String>();
            d.add(value);
            map_collection.put(key, d);
        } else {
            ArrayList<String> d = map_collection.get(key);
            d.add(value);
            map_collection.put(key, d);
        }
    }

    public static void generate_graph_nodes(List<LinkSource> graph_entries, Set<String> dataset, String output_file) {
        System.out.println("Generating graph " + output_file);

        for (String entry : dataset) {
            String[] values = entry.split(",");
            graph_entries.add(node(values[0]).link(node(values[1])));
            if (values[0].contains("*")) {
                graph_entries.add(node(values[0]).with(Color.RED));
            }
            if (values[1].contains("*")) {
                graph_entries.add(node(values[1]).with(Color.RED));
            }
            graph_entries.add(node(values[0]).link(node(values[1])));
        }

        Graph g = graph("example1").directed()
                .graphAttr().with(Rank.dir(LEFT_TO_RIGHT))
                .linkAttr().with("class", "link-class")
                .graphAttr().with(attr("pad", "0.5"), attr("ranksep", "2"), attr("nodesep", "0.5"))
                .nodeAttr().with(Font.name("Arial"))
                .with(graph_entries);
        try {
            Graphviz.fromGraph(g).height(10000).render(Format.PNG).toFile(new File(output_file));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void generate_graph(Set<String> dataset, String output_file) {
        List<LinkSource> graph_entries = new ArrayList<>();
        generate_graph_nodes(graph_entries, dataset, output_file);
    }

    public static void generate_graph(Set<String> dataset, String output_file,
            Map<String, ArrayList<String>> cluster_data) {
        List<LinkSource> graph_entries = new ArrayList<>();
        // Generate clusters
        for (Map.Entry<String, ArrayList<String>> entry : cluster_data.entrySet()) {
            String key = entry.getKey();
            List<String> values = entry.getValue();

            List<LinkSource> node_list = new ArrayList<>();
            for (String k : values) {
                node_list.add(node(k));
            }
            graph_entries.add(graph(key).cluster()
                    .nodeAttr().with(Style.FILLED, Color.WHITE)
                    .graphAttr().with(Style.FILLED, Color.LIGHTGREY, Label.of(key))
                    .with(node_list));
        }
        // Generate node graph
        generate_graph_nodes(graph_entries, dataset, output_file);
    }

    public static void generate_csv(String dir, String delimiter) throws IOException {
        System.out.println("Reading files under: " + dir);
        String[] ext = { "java" };
        Collection files = FileUtils.listFiles(new File(dir), ext, true);
        System.out.println("Total files to process: " + files.size());

        List<String[]> pkg_records = new ArrayList<String[]>();
        pkg_records.add(new String[] { "class", "package" });

        List<String[]> cls_records = new ArrayList<String[]>();
        cls_records.add(new String[] { "node1", "node2" });

        Iterator<File> it = files.iterator();
        while (it.hasNext()) {
            String filepath = it.next().toString();
            if (filepath.contains(test_folder_path.toString())) {
                continue;
            }
            String trimmed_filepath = filepath.substring(filepath.indexOf(delimiter) + delimiter.length()).trim()
                    .replace(File.separator, ".").replace(".java", "");

            try (BufferedReader br = new BufferedReader(new FileReader(filepath))) {
                String line;
                while ((line = br.readLine()) != null) {
                    if (line.matches("package\\s+com(.*)")) {
                        String pkg_name = line.replace("package ", "").trim().replace(";", "");
                        pkg_records.add(new String[] { trimmed_filepath, pkg_name });
                    }
                    if (line.matches("import\\s+com(.*)")) {
                        String cls_path = line.replace("import ", "").trim().replace(";", "");
                        cls_records.add(new String[] { trimmed_filepath, cls_path });
                    }
                }
            }
        }

        CSVWriter writer = new CSVWriter(new FileWriter("package_map.csv"));
        writer.writeAll(pkg_records);
        writer.close();

        writer = new CSVWriter(new FileWriter("class_dependency.csv"));
        writer.writeAll(cls_records);
        writer.close();

    }

    public static void main(String[] args) throws IOException, ParseException {

        CommandLine commandLine;
        Option option_d = Option.builder("d")
            .required(false)
            .desc("Path of project folder to parse java files")
            .longOpt("project-folder")
            .hasArg(true)
            .build();
        Option option_l = Option.builder("l")
            .required(false)
            .desc("Delimiter for project path")
            .longOpt("project-path-delimiter")
            .hasArg(true)
            .build();
        
        Options options = new Options();
        CommandLineParser parser = new DefaultParser();
        
        options.addOption(option_d);
        options.addOption(option_l);

        commandLine = parser.parse(options, args);

        String delimiter = "src"+File.separator+"main"+File.separator+"java"+File.separator;
        
        if (commandLine.hasOption("l"))
        {
            System.out.print("Delimiter: "+commandLine.getOptionValue("l")+"\n");
            delimiter = commandLine.getOptionValue("l");
        }

        if (commandLine.hasOption("d"))
        {
            System.out.print("Source folder: "+commandLine.getOptionValue("d")+"\n");
            generate_csv(commandLine.getOptionValue("d"), delimiter);
        } else {
            System.out.println("Skipping generation of csv, program assumes csv exists already\n");
        }

        Map<String, String> package_map = csv_as_map("package_map.csv");
        List<String[]> class_dependency = csv_as_array("class_dependency.csv");
        
        Set<String> pkg_dataset = new HashSet<String>();
        Set<String> cls_dataset = new HashSet<String>();

        Map<String, ArrayList<String>> package_collection = new HashMap<>();

        for (String[] record : class_dependency) {
            if (record.length == 2) {
                String node1 = record[0].toString();
                String node2 = record[1].toString();

                String package1 = package_map.getOrDefault(node1, "NoPackage");
                String package2 = package_map.getOrDefault(node2, "NoPackage");

                pkg_dataset.add(package1 + "," + package2);
                cls_dataset.add(node1 + "," + node2);

                // Save package collection
                upsert_map(package_collection, package1, node1);
                upsert_map(package_collection, package2, node2);
            }
        }

        // Generate package level graph
        generate_graph(pkg_dataset, "pkg_graph.png");

        // Generate class and package level graph
        generate_graph(cls_dataset, "cls_graph.png", package_collection);

        // Generate pom level graph if "pom_dependency.csv" exists
        String input_file="pom_dependency.csv";
        File f = new File(input_file);
        if(f.exists() && !f.isDirectory()) {
            List<String[]> pom_dependency = csv_as_array(input_file);
            Set<String> pom_dataset = new HashSet<String>();

            for (String[] record : pom_dependency) {
                if (record.length == 2) {
                    pom_dataset.add(record[0].toString() + "," + record[1].toString());
                }
            }
            generate_graph(pom_dataset, "pom_graph.png");
        }
    }
}
